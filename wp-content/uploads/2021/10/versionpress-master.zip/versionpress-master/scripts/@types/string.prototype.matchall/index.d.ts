function matchAll(str: string, regex: RegExp): Iterable<RegExpExecArray>;
export = matchAll;
